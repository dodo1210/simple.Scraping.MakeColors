# Community & governance

Keras is a fully open-source project with a community-first philosophy.
It is primarily developed at Google by the Keras team, with help from
a wide network of open-source developers.


## Governance: the Keras SIG

The evolution of the Keras project is guided by the [*Keras Special Interest Group* (Keras SIG)](https://github.com/keras-team/governance).

{{sig_readme}}



